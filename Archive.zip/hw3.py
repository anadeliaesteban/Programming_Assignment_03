from data import CountyDemographics

def population_total(counties: list[CountyDemographics]) -> int:
    population_2014_total = 0
    for county in counties:
        population_2014_total = population_2014_total + county.population["2014 Population"]
    return population_2014_total

# I created an accumulator named population_2014_total. I initialzed a running total of 0. 
# Then I wanted to loop through every county. 
# So I found the county list and added it to the running total of the population_2014_total. 
# I then returned the population_2014_total which is the sum of the 2014 Populations.

def filter_by_state(counties: list[CountyDemographics], state: str) -> list[CountyDemographics]:
    matching_counties = []
    for county in counties:
        if county.state == state:
            matching_counties.append(county)
    return matching_counties

# I started by creating an empty list so if there were no counties that matches
# the state inputed, it would return an empty list. Then I looped through the counties lsit,
# and if it matched the state inputed, it would append the county to the matching_counties list.
# I then returned the matching_counties list which contain all the counties that matched the state inputed.
    

def population_by_education(counties: list[CountyDemographics], key: str) -> float:
    population_education_total = 0
    for county in counties:
        population = county.population["2014 Population"]
        education_percentage = county.education.get(key, 0) / 100
        population_education_total = population_education_total + (population * education_percentage)
    return population_education_total

# I created an accumulator to calculate the total education population.
# I looped through every county and retrieved its 2014 population.
# Then I retrieved the education percentage and divided it by 100.
# I multiplied the population by the percentage and added the result.
# I returned the estimated total population for that education category.

def population_by_ethnicity(counties: list[CountyDemographics], key: str) -> float:
    population_ethnicity_total = 0
    for county in counties:
        population = county.population["2014 Population"]
        ethnicity_percentage = county.ethnicities.get(key, 0) / 100
        population_ethnicity_total = population_ethnicity_total + (population * ethnicity_percentage)
    return population_ethnicity_total

# I created an accumulator to calculate the total ethnicity population.
# I looped through every county and retrieved its 2014 population.
# Then I retrieved the ethnicity percentage and divided it by 100.
# I multiplied the population by the percentage and added the result.
# I returned the estimated total population for that ethnicity.

def population_below_poverty_level(counties: list[CountyDemographics]) -> float:
    population_poverty_total = 0
    for county in counties:
        population = county.population["2014 Population"]
        poverty_percentage = county.income.get("Persons Below Poverty Level", 0) / 100
        population_poverty_total = population_poverty_total + (population * poverty_percentage)
    return population_poverty_total

# I created an accumulator to calculate the total population below poverty.
# I looped through every county and retrieved its 2014 population.
# Then I retrieved the percentage below poverty and divided it by 100.
# I multiplied the population by the percentage and added the result.
# I returned the estimated total population below the poverty level.

def percent_by_education(counties: list[CountyDemographics], key: str) -> float:
    total_population = population_total(counties)
    if total_population == 0:
        return 0.0
    education_percent = (population_by_education(counties, key) / total_population ) * 100
    return education_percent

# I retrieved the total population across all supplied counties.
# If the total population was 0, I returned 0 to avoid division by zero.
# Otherwise, I divided the education population by the total population.
# I multiplied the result by 100 to convert it into a percentage.
# I returned the final education percentage.

def percent_by_ethnicity(counties: list[CountyDemographics], key: str) -> float:
    total_population = population_total(counties)
    if total_population == 0:
        return 0.0
    ethnicity_percent = (population_by_ethnicity(counties, key) / total_population) * 100
    return ethnicity_percent

# I retrieved the total population across all supplied counties.
# If the total population was 0, I returned 0 to avoid division by zero.
# Otherwise, I divided the ethnicity population by the total population.
# I multiplied the result by 100 to convert it into a percentage.
# I returned the final ethnicity percentage.

def percent_below_poverty_level(counties: list[CountyDemographics]) -> float:
    total_population = population_total(counties)
    if total_population == 0:
        return 0.0
    poverty_percentage = (population_below_poverty_level(counties) / total_population) * 100
    return poverty_percentage
    
#I retrieved the total population across all supplied counties.
# If the total population was 0, I returned 0 to avoid division by zero.
# Otherwise, I divided the poverty population by the total population.
# I multiplied the result by 100 to convert it into a percentage.
# I returned the final poverty percentage.

def education_greater_than(counties: list[CountyDemographics], key: str, threshold: float) -> list[CountyDemographics]:
    matching_counties = []
    for county in counties:
        if key in county.education:
            if county.education[key] > threshold:
                matching_counties.append(county)
    return matching_counties

# I created an empty list to store counties above the education threshold.
# I looped through every county and checked whether the education key existed.
# If its percentage was greater than the threshold, I added the county.
# I returned the list containing all matching counties.

def education_less_than(counties: list[CountyDemographics], key: str, threshold: float) -> list[CountyDemographics]:
    matching_counties = []
    for county in counties:
        if key in county.education:
            if county.education[key] < threshold:
                matching_counties.append(county)
    return matching_counties

# I created an empty list to store counties below the education threshold.
# I looped through every county and checked whether the education key existed.
# If its percentage was less than the threshold, I added the county.
# I returned the list containing all matching counties.


def ethnicity_greater_than(counties: list[CountyDemographics], key: str, threshold: float) -> list[CountyDemographics]:
    # I created an empty list to store counties above the ethnicity threshold.
    # I looped through every county and checked whether the ethnicity key existed.
    # If its percentage was greater than the threshold, I added the county.
    # I returned the list containing all matching counties.
    matching_counties = []
    for county in counties:
        if key in county.ethnicities:
            if county.ethnicities[key] > threshold:
                matching_counties.append(county)
    return matching_counties


def ethnicity_less_than(counties: list[CountyDemographics], key: str, threshold: float) -> list[CountyDemographics]:
    matching_counties = []
    for county in counties:
        if key in county.ethnicities:
            if county.ethnicities[key] < threshold:
                matching_counties.append(county)
    return matching_counties

# I created an empty list to store counties below the ethnicity threshold.
# I looped through every county and checked whether the ethnicity key existed.
# If its percentage was less than the threshold, I added the county.
# I returned the list containing all matching counties.

def ethnicity_greater_than(counties: list[CountyDemographics], key: str, threshold: float) -> list[CountyDemographics]:
    matching_counties = []
    for county in counties:
        if key in county.ethnicities:
            if county.ethnicities[key] > threshold:
                matching_counties.append(county)
    return matching_counties

# I created an empty list to store counties above the ethnicity threshold.
# I looped through every county and checked whether the ethnicity key existed.
# If its percentage was greater than the threshold, I added the county.
# I returned the list containing all matching counties.

def below_poverty_level_greater_than(counties: list[CountyDemographics], threshold: float) -> list[CountyDemographics]:
    matching_counties = []
    for county in counties:
        if "Persons Below Poverty Level" in county.income:
            if county.income["Persons Below Poverty Level"] > threshold:
                matching_counties.append(county)
    return matching_counties

# I created an empty list to store counties above the poverty threshold.
# I looped through every county and checked whether the poverty key existed.
# If its percentage was greater than the threshold, I added the county.
# I returned the list containing all matching counties.

def below_poverty_level_less_than(counties: list[CountyDemographics], threshold: float) -> list[CountyDemographics]:
    matching_counties = []
    for county in counties:
        if "Persons Below Poverty Level" in county.income:
            if county.income["Persons Below Poverty Level"] < threshold:
                matching_counties.append(county)
    return matching_counties

# I created an empty list to store counties below the poverty threshold.
# I looped through every county and checked whether the poverty key existed.
# If its percentage was less than the threshold, I added the county.
# I returned the list containing all matching counties.